
Resources used in getting some help:-	google.com/
					udacity.com/
					stackoverflow.com/
					https://pandas.pydata.org/docs/
					https://www.programiz.com/

Please accept my sincere apology for the delay
         'Khaled Fouad'